"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancellationArchiveCollection = void 0;
exports.cancelledAnnouncementHistory = cancelledAnnouncementHistory;
exports.archiveCancelledAnnouncement = archiveCancelledAnnouncement;
exports.archiveLegacyCancellation = archiveLegacyCancellation;
exports.revokeCancelledAnnouncementAttachments = revokeCancelledAnnouncementAttachments;
const firestore_1 = require("firebase-admin/firestore");
const storage_1 = require("firebase-admin/storage");
exports.cancellationArchiveCollection = 'presidentInstructionCancellationArchive';
/** Keep the same document ID and query shape for old clients, with a safe history entry. */
function cancelledAnnouncementHistory(row) {
    const { authorId, authorName, authorRole, sourceLocale, createdAt, updatedAt, cancelledAt, cancelledBy, cancellationReason, replacedByInstructionId, replacesInstructionId, isDemo, demoDatasetId, seedVersion, submissionFingerprint } = row;
    return Object.fromEntries(Object.entries({
        authorId, authorName, authorRole, sourceLocale, createdAt, updatedAt, cancelledAt,
        cancelledBy, cancellationReason, replacedByInstructionId, replacesInstructionId,
        isDemo, demoDatasetId, seedVersion, submissionFingerprint,
        titleOriginal: '', bodyOriginal: '', priority: 'normal', dueDate: '',
        status: 'cancelled', recipientIds: [], recipientStates: {}, attachments: []
    }).filter(([, value]) => value !== undefined));
}
function archiveRef(db, id) {
    return db.collection(exports.cancellationArchiveCollection).doc(id);
}
function archiveCancelledAnnouncement(db, tx, ref, original, cancellation) {
    const cancelled = { ...original, ...cancellation };
    // The archive has no client read or write permission. Replies stay in their original subcollection.
    tx.create(archiveRef(db, ref.id), cancelled);
    tx.set(ref, cancelledAnnouncementHistory(cancelled));
}
async function archiveLegacyCancellation(db, id) {
    const ref = db.collection('presidentInstructions').doc(id);
    return db.runTransaction(async (tx) => {
        const [current, archive] = await Promise.all([tx.get(ref), tx.get(archiveRef(db, id))]);
        const row = current.data();
        if (row?.status !== 'cancelled' || archive.exists)
            return false;
        archiveCancelledAnnouncement(db, tx, ref, row, {});
        return true;
    });
}
function attachmentPrefix(row, id) {
    return `${row.isDemo === true ? `demo/${row.demoDatasetId}/` : ''}president-instructions/${id}/${row.authorId}/`;
}
function attachmentPath(attachment, prefix, bucketName) {
    let path = attachment.storagePath;
    if (!path && attachment.downloadUrl) {
        const url = new URL(attachment.downloadUrl);
        const endpoint = `/v0/b/${bucketName}/o/`;
        if (url.origin !== 'https://firebasestorage.googleapis.com' || !url.pathname.startsWith(endpoint)) {
            throw new Error('Unrecognized legacy announcement attachment URL');
        }
        path = decodeURIComponent(url.pathname.slice(endpoint.length));
    }
    if (typeof path !== 'string' || !path.startsWith(prefix) || !path.slice(prefix.length) || path.slice(prefix.length).includes('/')) {
        throw new Error('Announcement attachment is outside the cancelled post folder');
    }
    return path;
}
/** Firebase download tokens outlive a Rules change. Remove them from the original objects. */
async function revokeCancelledAnnouncementAttachments(db, id, getBucket = () => (0, storage_1.getStorage)().bucket()) {
    const ref = archiveRef(db, id);
    const row = (await ref.get()).data();
    if (!row || row.attachmentAccessRevokedAt)
        return;
    if (row.attachments?.length) {
        const bucket = getBucket();
        const prefix = attachmentPrefix(row, id);
        const paths = new Set(row.attachments.map((attachment) => attachmentPath(attachment, prefix, bucket.name)));
        await Promise.all([...paths].map(async (path) => {
            try {
                await bucket.file(path).setMetadata({
                    cacheControl: 'private, no-store', metadata: { firebaseStorageDownloadTokens: null }
                });
            }
            catch (error) {
                if (Number(error?.code) !== 404)
                    throw error;
            }
        }));
    }
    await ref.update({ attachmentAccessRevokedAt: firestore_1.FieldValue.serverTimestamp() });
}
