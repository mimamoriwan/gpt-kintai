import { z } from "zod";
export declare const attachmentTagsSchema: z.ZodPipe<z.ZodArray<z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>, z.ZodString>>, z.ZodTransform<string[], string[]>>;
export declare const updateAttachmentTagsSchema: z.ZodObject<{
    instructionId: z.ZodString;
    attachmentId: z.ZodString;
    tags: z.ZodPipe<z.ZodArray<z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>, z.ZodString>>, z.ZodTransform<string[], string[]>>;
    previousTags: z.ZodPipe<z.ZodArray<z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>, z.ZodString>>, z.ZodTransform<string[], string[]>>;
}, z.core.$strip>;
export declare const suggestAttachmentTagsSchema: z.ZodObject<{
    name: z.ZodString;
    excerpt: z.ZodString;
    locale: z.ZodEnum<{
        ja: "ja";
        "zh-CN": "zh-CN";
    }>;
    candidates: z.ZodPipe<z.ZodArray<z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>, z.ZodString>>, z.ZodTransform<string[], string[]>>;
    sourceAttachment: z.ZodOptional<z.ZodObject<{
        instructionId: z.ZodString;
        attachmentId: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type AttachmentTagSuggestion = z.infer<typeof suggestAttachmentTagsSchema>;
export declare function suggestTagsFromText(apiKey: string, uid: string, input: AttachmentTagSuggestion): Promise<string[]>;
