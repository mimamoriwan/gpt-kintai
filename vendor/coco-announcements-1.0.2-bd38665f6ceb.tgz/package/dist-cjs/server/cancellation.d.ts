import { type DocumentReference, type Firestore, type Transaction } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
export declare const cancellationArchiveCollection = "presidentInstructionCancellationArchive";
type Row = Record<string, any>;
/** Keep the same document ID and query shape for old clients, with a safe history entry. */
export declare function cancelledAnnouncementHistory(row: Row): Row;
export declare function archiveCancelledAnnouncement(db: Firestore, tx: Transaction, ref: DocumentReference, original: Row, cancellation: Row): void;
export declare function archiveLegacyCancellation(db: Firestore, id: string): Promise<boolean>;
/** Firebase download tokens outlive a Rules change. Remove them from the original objects. */
export declare function revokeCancelledAnnouncementAttachments(db: Firestore, id: string, getBucket?: () => ReturnType<ReturnType<typeof getStorage>['bucket']>): Promise<void>;
export {};
