export declare const maxAttachmentTags = 3;
export declare const maxAttachmentTagLength = 32;
export declare const maxAttachmentTagCandidates = 25;
export declare const maxAttachmentExcerptLength = 6000;
export declare function normalizeAttachmentTag(value: string): string;
export declare function attachmentTagKey(value: string): string;
export declare function uniqueAttachmentTags(values: readonly string[]): string[];
