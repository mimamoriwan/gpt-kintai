export declare const ANNOUNCEMENT_RELEASE: Readonly<{
    version: "1.0.2";
    sourceHash: "bd38665f6cebbdbc2a9cc1cf02c6908261b67e65244d46c7c8373d6b7f04b33c";
    apiVersion: 1;
}>;
