"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.maxAttachmentExcerptLength = exports.maxAttachmentTagCandidates = exports.maxAttachmentTagLength = exports.maxAttachmentTags = void 0;
exports.normalizeAttachmentTag = normalizeAttachmentTag;
exports.attachmentTagKey = attachmentTagKey;
exports.uniqueAttachmentTags = uniqueAttachmentTags;
exports.maxAttachmentTags = 3;
exports.maxAttachmentTagLength = 32;
exports.maxAttachmentTagCandidates = 25;
exports.maxAttachmentExcerptLength = 6_000;
function normalizeAttachmentTag(value) {
    return value.normalize("NFKC").trim().replace(/\s+/gu, " ");
}
function attachmentTagKey(value) {
    return normalizeAttachmentTag(value).toLowerCase();
}
function uniqueAttachmentTags(values) {
    const byKey = new Map();
    for (const raw of values) {
        const tag = normalizeAttachmentTag(raw);
        const key = attachmentTagKey(tag);
        if (key && !byKey.has(key))
            byKey.set(key, tag);
    }
    return [...byKey.values()];
}
