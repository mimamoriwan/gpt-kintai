"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.announcementId = void 0;
exports.sameAnnouncementScope = sameAnnouncementScope;
exports.serializeAnnouncement = serializeAnnouncement;
exports.createAnnouncementReader = createAnnouncementReader;
exports.uploadAnnouncementAttachment = uploadAnnouncementAttachment;
const storage_1 = require("firebase-admin/storage");
const firestore_1 = require("firebase-admin/firestore");
const https_1 = require("firebase-functions/v2/https");
const zod_1 = require("zod");
const release_js_1 = require("../release.js");
exports.announcementId = zod_1.z.string().trim().min(1).max(128).refine(id => !id.includes('/') && id !== '.' && id !== '..');
function sameAnnouncementScope(profile, row) {
    return profile.isDemo === true ? row.isDemo === true && profile.demoDatasetId === row.demoDatasetId : row.isDemo !== true;
}
function serializeAnnouncement(value) {
    if (value instanceof firestore_1.Timestamp)
        return { $timestamp: value.toMillis() };
    if (Array.isArray(value))
        return value.map(serializeAnnouncement);
    if (value && typeof value === 'object')
        return Object.fromEntries(Object.entries(value).filter(([key]) => !['submissionFingerprint', 'translationLeaseId', 'translationLeaseUntil', 'translationError'].includes(key)).map(([key, item]) => [key, serializeAnnouncement(item)]));
    return value;
}
function createAnnouncementReader(db) {
    async function profile(auth) {
        const row = (await db.doc(`users/${auth.uid}`).get()).data();
        if (!row || row.uid !== auth.uid || row.active !== true)
            throw new https_1.HttpsError('permission-denied', '利用者を確認してください。');
        return row;
    }
    async function instruction(auth, rawId) {
        const id = exports.announcementId.parse(rawId), actor = await profile(auth);
        const row = (await db.doc(`presidentInstructions/${id}`).get()).data();
        if (!row)
            throw new https_1.HttpsError('not-found', 'お知らせがありません。');
        if (!sameAnnouncementScope(actor, row) || (row.authorId !== auth.uid && !row.recipientIds?.includes(auth.uid)))
            throw new https_1.HttpsError('permission-denied', 'このお知らせは閲覧できません。');
        return { id, ...row };
    }
    return {
        instruction,
        async snapshot(auth) {
            const actor = await profile(auth);
            const collection = db.collection('presidentInstructions');
            const [incoming, sent, users] = await Promise.all([
                collection.where('recipientIds', 'array-contains', auth.uid).get(), collection.where('authorId', '==', auth.uid).get(), db.collection('users').limit(100).get()
            ]);
            const merged = new Map([...incoming.docs, ...sent.docs].filter(item => sameAnnouncementScope(actor, item.data())).map(item => [item.id, { id: item.id, ...item.data() }]));
            const recipients = users.docs.filter(item => item.data().active !== false && sameAnnouncementScope(actor, item.data())).map(item => ({ uid: item.id, displayName: String(item.data().displayName || '').trim(), role: String(item.data().role || 'employee'), active: true })).filter(item => item.displayName).sort((a, b) => a.displayName.localeCompare(b.displayName, 'ja'));
            return serializeAnnouncement({ release: release_js_1.ANNOUNCEMENT_RELEASE, instructions: [...merged.values()].sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0)), recipients, profile: { uid: auth.uid, email: String(actor.email || ''), displayName: String(actor.displayName || ''), role: actor.role, locale: actor.locale === 'zh-CN' ? 'zh-CN' : 'ja', active: true, isDemo: actor.isDemo === true, ...(actor.isDemo ? { demoDatasetId: actor.demoDatasetId, seedVersion: actor.seedVersion } : {}) } });
        },
        async messages(auth, input) {
            const data = zod_1.z.object({ instructionId: exports.announcementId, recipientId: exports.announcementId, count: zod_1.z.number().int().min(50).max(10000) }).parse(input);
            const row = await instruction(auth, data.instructionId);
            if (!row.recipientIds.includes(data.recipientId) || (auth.uid !== row.authorId && auth.uid !== data.recipientId))
                throw new https_1.HttpsError('permission-denied', 'この会話は閲覧できません。');
            const snapshot = await db.collection(`presidentInstructions/${data.instructionId}/conversations/${data.recipientId}/messages`).orderBy('createdAt', 'asc').limitToLast(data.count).get();
            return serializeAnnouncement(snapshot.docs.map(item => ({ ...item.data(), id: item.id })));
        },
        async attachment(auth, input) {
            const data = zod_1.z.object({ instructionId: exports.announcementId, attachmentId: zod_1.z.string().uuid() }).parse(input);
            const row = await instruction(auth, data.instructionId);
            const file = row.attachments?.find((item) => item.id === data.attachmentId);
            if (!file?.storagePath)
                throw new https_1.HttpsError('not-found', '添付資料がありません。');
            return file;
        }
    };
}
/** Immutable upload into the same paths and metadata used by the existing app. */
async function uploadAnnouncementAttachment(db, auth, input, bytes, getBucket = () => (0, storage_1.getStorage)().bucket()) {
    const data = zod_1.z.object({ instructionId: zod_1.z.string().uuid(), attachmentId: zod_1.z.string().uuid(), name: zod_1.z.string().trim().min(1).max(180), contentType: zod_1.z.enum(['image/jpeg', 'image/png', 'application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']) }).parse(input);
    const profile = (await db.doc(`users/${auth.uid}`).get()).data();
    if (!profile || profile.active !== true)
        throw new https_1.HttpsError('permission-denied', '利用者を確認してください。');
    const image = data.contentType.startsWith('image/');
    if (!bytes.length || bytes.length > (image ? 1024 * 1024 : 10 * 1024 * 1024))
        throw new https_1.HttpsError('invalid-argument', '添付資料の容量を確認してください。');
    const signature = data.contentType === 'image/jpeg' ? bytes.subarray(0, 3).equals(Buffer.from([255, 216, 255])) : data.contentType === 'image/png' ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) : data.contentType === 'application/pdf' ? bytes.subarray(0, 5).toString() === '%PDF-' : bytes.length >= 4 && bytes[0] === 80 && bytes[1] === 75 && [3, 5, 7].includes(bytes[2]) && [4, 6, 8].includes(bytes[3]);
    if (!signature)
        throw new https_1.HttpsError('invalid-argument', '添付資料の形式を確認してください。');
    const prefix = profile.isDemo === true ? `demo/${String(profile.demoDatasetId)}/` : '';
    const name = data.name.normalize('NFKC').replace(/[^\p{L}\p{N}._-]+/gu, '_').slice(0, 80) || 'attachment';
    const storagePath = `${prefix}president-instructions/${data.instructionId}/${auth.uid}/${data.attachmentId}-${name}`;
    const file = getBucket().file(storagePath);
    try {
        await file.save(bytes, { resumable: false, preconditionOpts: { ifGenerationMatch: 0 }, metadata: { contentType: data.contentType, cacheControl: 'private, no-store', metadata: { ownerId: auth.uid, instructionId: data.instructionId } } });
    }
    catch (error) {
        if (Number(error?.code) !== 412)
            throw error;
        const [existing] = await file.download();
        if (!existing.equals(bytes))
            throw new https_1.HttpsError('already-exists', '同じ添付IDで別の資料を送信できません。');
    }
    return { id: data.attachmentId, name: data.name, contentType: data.contentType, size: bytes.length, storagePath };
}
