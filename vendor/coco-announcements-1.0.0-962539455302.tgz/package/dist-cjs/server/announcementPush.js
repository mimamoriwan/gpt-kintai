"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PUSH_LIFETIME_MS = void 0;
exports.registerPushDevice = registerPushDevice;
exports.unregisterPushDevice = unregisterPushDevice;
exports.testPushDevice = testPushDevice;
exports.deliverAnnouncementPush = deliverAnnouncementPush;
const node_crypto_1 = require("node:crypto");
const firestore_1 = require("firebase-admin/firestore");
const https_1 = require("firebase-functions/v2/https");
const zod_1 = require("zod");
const workAuth_js_1 = require("./workAuth.js");
const deviceId = zod_1.z.string().regex(/^[A-Za-z0-9_-]{20,100}$/);
const revokeKey = zod_1.z.string().regex(/^[a-f0-9]{64}$/);
const registration = zod_1.z.object({ deviceId, revokeKey, token: zod_1.z.string().min(20).max(4096), locale: zod_1.z.enum(["ja", "zh-CN"]) }).strict();
const removal = zod_1.z.object({ deviceId, revokeKey }).strict();
exports.PUSH_LIFETIME_MS = 24 * 60 * 60 * 1000;
const hash = (value) => (0, node_crypto_1.createHash)("sha256").update(value).digest("hex");
const millis = (value) => value instanceof firestore_1.Timestamp ? value.toMillis() : NaN;
function validAccount(profile, authTime) {
    return !!profile && profile.active === true && profile.isDemo !== true
        && ["employee", "employee_manager", "president_viewer"].includes(profile.role)
        && profile.passwordChangeRequired !== true
        && (!("passwordAuthTimeAfter" in profile) || (typeof authTime === "number"
            && Number.isFinite(profile.passwordAuthTimeAfter) && authTime > profile.passwordAuthTimeAfter));
}
async function authenticate(db, auth) {
    const context = await (0, workAuth_js_1.requireWorkAuth)(auth, async (uid) => (await db.doc(`users/${uid}`).get()).data());
    const profile = (await db.doc(`users/${context.uid}`).get()).data();
    if (!validAccount(profile, Number(context.token.auth_time)))
        throw new https_1.HttpsError("permission-denied", "このアカウントでは通知を利用できません。");
    return context;
}
async function registerPushDevice(db, auth, raw, now = firestore_1.Timestamp.now(), application = 'gpt-kintai') {
    const context = await authenticate(db, auth);
    const input = registration.parse(raw);
    const ref = db.doc(`announcementPushDevices/${input.deviceId}`);
    const tokenRef = db.doc(`announcementPushTokenOwners/${hash(input.token)}`);
    await db.runTransaction(async (tx) => {
        const [existing, owner, user] = await Promise.all([tx.get(ref), tx.get(tokenRef), tx.get(db.doc(`users/${context.uid}`))]);
        if (user.data()?.uid !== context.uid || !validAccount(user.data(), Number(context.token.auth_time)))
            throw new https_1.HttpsError("permission-denied", "アカウントを確認してください。");
        const previous = existing.data();
        if (previous && previous.revokeKeyHash !== hash(input.revokeKey))
            throw new https_1.HttpsError("permission-denied", "端末の登録情報が一致しません。");
        if (owner.exists && owner.data()?.deviceId !== input.deviceId)
            throw new https_1.HttpsError("already-exists", "この通知先は別の端末情報に登録されています。");
        if (previous?.token && previous.token !== input.token)
            tx.delete(db.doc(`announcementPushTokenOwners/${hash(previous.token)}`));
        tx.set(ref, {
            userId: context.uid, token: input.token, locale: input.locale, application,
            revokeKeyHash: hash(input.revokeKey), authTime: context.token.auth_time ?? 0,
            createdAt: previous?.userId === context.uid ? previous.createdAt : now, updatedAt: now,
            ...(previous?.userId === context.uid && previous.lastTestAt instanceof firestore_1.Timestamp ? { lastTestAt: previous.lastTestAt } : {})
        });
        tx.set(tokenRef, { deviceId: input.deviceId });
    });
    return { registered: true };
}
// This single-device revocation capability also works after an offline logout.
// It cannot register, inspect, send, or revoke any other installation.
async function unregisterPushDevice(db, raw) {
    const input = removal.parse(raw);
    const ref = db.doc(`announcementPushDevices/${input.deviceId}`);
    await db.runTransaction(async (tx) => {
        const snapshot = await tx.get(ref);
        if (!snapshot.exists)
            return;
        const row = snapshot.data();
        const actual = Buffer.from(hash(input.revokeKey));
        const expected = Buffer.from(String(row.revokeKeyHash || ""));
        if (actual.length !== expected.length || !(0, node_crypto_1.timingSafeEqual)(actual, expected))
            throw new https_1.HttpsError("permission-denied", "端末の解除情報が一致しません。");
        tx.delete(ref);
        tx.delete(db.doc(`announcementPushTokenOwners/${hash(row.token)}`));
    });
    return { removed: true };
}
async function enabledFor(db, uid) {
    const config = (await db.doc("announcementPushConfig/default").get()).data();
    return config?.enabled === true && Array.isArray(config.allowedUserIds) && config.allowedUserIds.includes(uid);
}
function message(token, userId, eventId, instructionId, locale, ttlSeconds) {
    return { token, data: { type: instructionId ? "announcement" : "test", eventId, instructionId, locale, userId },
        webpush: { headers: { TTL: String(Math.max(0, ttlSeconds)), Urgency: "normal" } } };
}
const invalidToken = (error) => ["messaging/registration-token-not-registered", "messaging/invalid-registration-token"].includes(errorCode(error));
function errorCode(error) {
    const code = error && typeof error === "object" && "code" in error ? String(error.code) : "unknown";
    return /^messaging\/[a-z-]+$/.test(code) ? code : "unknown";
}
const transient = (error) => ["unknown", "messaging/internal-error", "messaging/server-unavailable", "messaging/unknown-error", "messaging/quota-exceeded", "messaging/message-rate-exceeded"].includes(errorCode(error));
async function removeInvalidDevice(db, ref, token) {
    await db.runTransaction(async (tx) => {
        const snapshot = await tx.get(ref);
        if (snapshot.data()?.token !== token)
            return;
        tx.delete(ref);
        tx.delete(db.doc(`announcementPushTokenOwners/${hash(token)}`));
    });
}
async function testPushDevice(db, sender, auth, raw, now = firestore_1.Timestamp.now()) {
    const context = await authenticate(db, auth);
    const { deviceId: id, revokeKey: key } = removal.parse(raw);
    if (!await enabledFor(db, context.uid))
        throw new https_1.HttpsError("failed-precondition", "通知の試験利用はまだ有効になっていません。");
    const ref = db.doc(`announcementPushDevices/${id}`);
    const row = await db.runTransaction(async (tx) => {
        const [device, user] = await Promise.all([tx.get(ref), tx.get(db.doc(`users/${context.uid}`))]);
        const value = device.data();
        if (user.data()?.uid !== context.uid || !validAccount(user.data(), Number(context.token.auth_time)) || value?.userId !== context.uid || value.revokeKeyHash !== hash(key))
            throw new https_1.HttpsError("permission-denied", "本人の登録済み端末で試してください。");
        if (now.toMillis() - millis(value.lastTestAt) < 60_000)
            throw new https_1.HttpsError("resource-exhausted", "テスト通知は1分ほど待ってから送ってください。");
        tx.update(ref, { lastTestAt: now });
        return value;
    });
    try {
        await sender.send(message(row.token, context.uid, `test-${(0, node_crypto_1.randomUUID)()}`, "", row.locale, 300));
    }
    catch (error) {
        if (invalidToken(error))
            await removeInvalidDevice(db, ref, row.token);
        throw new https_1.HttpsError("unavailable", "テスト通知を送信できませんでした。通知設定を確認してください。");
    }
    return { accepted: true };
}
async function deliverAnnouncementPush(db, sender, instructionId, now = firestore_1.Timestamp.now()) {
    const instruction = (await db.doc(`presidentInstructions/${instructionId}`).get()).data();
    if (!instruction || instruction.isDemo === true || instruction.status !== "active")
        return;
    const age = now.toMillis() - millis(instruction.createdAt);
    if (!Number.isFinite(age) || age < 0 || age >= exports.PUSH_LIFETIME_MS)
        return;
    const recipients = [...new Set(Array.isArray(instruction.recipientIds) ? instruction.recipientIds : [])]
        .filter(uid => typeof uid === "string" && uid !== instruction.authorId && /^[^/]{1,128}$/.test(uid));
    let retry = false;
    for (const uid of recipients) {
        if (!await enabledFor(db, uid))
            continue;
        const devices = await db.collection("announcementPushDevices").where("userId", "==", uid).get();
        for (const device of devices.docs) {
            const ledger = db.doc(`announcementPushDeliveries/${hash(`${instructionId}:${device.id}`)}`);
            const leaseId = (0, node_crypto_1.randomUUID)();
            const outcome = await db.runTransaction(async (tx) => {
                const [saved, current, user, post, config] = await Promise.all([
                    tx.get(ledger), tx.get(device.ref), tx.get(db.doc(`users/${uid}`)),
                    tx.get(db.doc(`presidentInstructions/${instructionId}`)), tx.get(db.doc("announcementPushConfig/default"))
                ]);
                const row = current.data();
                if (row?.application === 'coco') {
                    const [member, settings] = await Promise.all([tx.get(db.doc(`cocoMembers/${uid}`)), tx.get(db.doc('cocoSettings/announcements'))]);
                    if (member.data()?.active !== true || member.data()?.uid !== uid || member.data()?.legacyKintaiUid !== uid || settings.data()?.enabled !== true || settings.data()?.pushEnabled !== true || (Array.isArray(settings.data()?.allowedUserIds) && !settings.data().allowedUserIds.includes(uid)))
                        return { kind: 'skip' };
                }
                else if ((await tx.get(db.doc('cocoSettings/announcements'))).data()?.legacyPushEnabled === false)
                    return { kind: 'skip' };
                const latest = post.data();
                const settings = config.data();
                if (!row || row.userId !== uid || user.data()?.uid !== uid || !validAccount(user.data(), row.authTime)
                    || millis(row.createdAt) > millis(instruction.createdAt)
                    || !latest || latest.status !== "active" || latest.isDemo === true || !latest.recipientIds?.includes(uid)
                    || settings?.enabled !== true || !settings.allowedUserIds?.includes(uid))
                    return { kind: "skip" };
                const prior = saved.data();
                if (["accepted", "failed"].includes(prior?.status))
                    return { kind: "skip" };
                if (prior?.status === "sending" && millis(prior.leaseUntil) > now.toMillis())
                    return { kind: "busy" };
                tx.set(ledger, { instructionId, deviceId: device.id, status: "sending", leaseId,
                    leaseUntil: firestore_1.Timestamp.fromMillis(now.toMillis() + 120_000), updatedAt: now,
                    attempts: Number(prior?.attempts || 0) + 1 });
                return { kind: "send", row };
            });
            if (outcome.kind === "busy") {
                retry = true;
                continue;
            }
            if (outcome.kind !== "send")
                continue;
            let status = "accepted", code = "";
            try {
                await sender.send(message(outcome.row.token, uid, `announcement-${instructionId}`, instructionId, outcome.row.locale, Math.floor((exports.PUSH_LIFETIME_MS - age) / 1000)));
            }
            catch (error) {
                code = errorCode(error);
                status = transient(error) ? "retry" : "failed";
                if (status === "retry")
                    retry = true;
                if (invalidToken(error))
                    await removeInvalidDevice(db, device.ref, outcome.row.token);
                console.warn("announcement-push-send", { instructionId, status, code });
            }
            await db.runTransaction(async (tx) => {
                const current = await tx.get(ledger);
                if (current.data()?.leaseId === leaseId)
                    tx.update(ledger, { status, code, updatedAt: now });
            });
        }
    }
    if (retry)
        throw new Error("announcement-push-retry");
}
