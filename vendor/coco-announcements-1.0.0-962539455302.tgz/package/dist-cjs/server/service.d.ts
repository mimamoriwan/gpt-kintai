import { type Firestore, type Transaction } from 'firebase-admin/firestore';
export type AuthContext = {
    uid: string;
    token: Record<string, unknown>;
};
export type AnnouncementOperation = "createPresidentInstruction" | "remindPresidentInstruction" | "replyToPresidentInstruction" | "acknowledgePresidentInstruction" | "completePresidentInstruction" | "cancelPresidentInstruction" | "replacePresidentInstruction" | "retryPresidentInstructionTranslation" | "listAnnouncementRecipients";
export interface AnnouncementDependencies {
    db: Firestore;
    getApiKey: () => string;
    source: 'gpt-kintai' | 'coco';
    authorize: (auth: AuthContext | undefined, tx?: Transaction) => Promise<AuthContext>;
    requestId?: string;
    trace?: (entry: {
        requestId: string;
        source: string;
        operation: string;
        stage: string;
        result: string;
        code?: string;
    }) => void;
    translate?: (input: {
        title: string;
        body: string;
        sourceLocale: string;
        uid: string;
    }) => Promise<{
        title: string;
        body: string;
    }>;
}
export declare function createAnnouncementService(dependencies: AnnouncementDependencies): {
    execute: (operation: AnnouncementOperation, auth: AuthContext | undefined, data: unknown) => Promise<any>;
};
/** Recheck revocation/membership in every write transaction; audit origin is server-owned. */
export declare function guardedFirestore(db: Firestore, auth: AuthContext | undefined, authorize: AnnouncementDependencies['authorize'], source: string, requestId: string): Firestore;
