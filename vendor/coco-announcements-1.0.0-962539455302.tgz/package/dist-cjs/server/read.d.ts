import { getStorage } from 'firebase-admin/storage';
import { type Firestore } from 'firebase-admin/firestore';
import { z } from 'zod';
import type { AuthContext } from './service.js';
export declare const announcementId: z.ZodString;
export declare function sameAnnouncementScope(profile: Record<string, any>, row: Record<string, any>): boolean;
export declare function serializeAnnouncement(value: any): any;
export declare function createAnnouncementReader(db: Firestore): {
    instruction: (auth: AuthContext, rawId: unknown) => Promise<Record<string, any>>;
    snapshot(auth: AuthContext): Promise<any>;
    messages(auth: AuthContext, input: unknown): Promise<any>;
    attachment(auth: AuthContext, input: unknown): Promise<{
        id: string;
        name: string;
        size: number;
        storagePath: string;
        contentType: string;
    }>;
};
/** Immutable upload into the same paths and metadata used by the existing app. */
export declare function uploadAnnouncementAttachment(db: Firestore, auth: AuthContext, input: unknown, bytes: Buffer, getBucket?: () => ReturnType<ReturnType<typeof getStorage>['bucket']>): Promise<{
    id: string;
    name: string;
    contentType: "image/jpeg" | "image/png" | "application/pdf" | "application/vnd.openxmlformats-officedocument.wordprocessingml.document" | "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    size: number;
    storagePath: string;
}>;
