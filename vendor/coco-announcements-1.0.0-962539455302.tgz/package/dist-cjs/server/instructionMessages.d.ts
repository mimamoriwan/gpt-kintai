import { type Firestore } from "firebase-admin/firestore";
/** Append an immutable, retry-safe message without changing confirmation/completion state. */
export declare function sendInstructionMessage(firestore: Firestore, actorId: string | undefined, data: unknown): Promise<{
    ok: true;
    id: string;
}>;
