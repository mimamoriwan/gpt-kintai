export type PasswordAuthContext = {
    uid: string;
    token: Record<string, unknown>;
};
type Profile = Record<string, unknown>;
export declare function requireWorkAuth(auth: PasswordAuthContext | undefined, readProfile: (uid: string) => Promise<Profile | undefined>): Promise<PasswordAuthContext>;
export {};
