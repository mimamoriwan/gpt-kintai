"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAnnouncementService = createAnnouncementService;
exports.guardedFirestore = guardedFirestore;
const node_crypto_1 = require("node:crypto");
const firestore_1 = require("firebase-admin/firestore");
const storage_1 = require("firebase-admin/storage");
const https_1 = require("firebase-functions/v2/https");
const openai_1 = __importDefault(require("openai"));
const zod_1 = require("zod");
const instructionMessages_js_1 = require("./instructionMessages.js");
const instructionReminders_js_1 = require("./instructionReminders.js");
function createAnnouncementService(dependencies) {
    return { execute: (operation, auth, data) => execute(dependencies, operation, auth, data) };
}
async function execute(dependencies, operation, context, data) {
    const request = { auth: context, data };
    const requestId = dependencies.requestId || (0, node_crypto_1.randomUUID)();
    let stage = 'authorize';
    const firestore = guardedFirestore(dependencies.db, context, dependencies.authorize, dependencies.source, requestId);
    const requireAuth = async (auth) => { const result = await dependencies.authorize(auth); stage = 'persist'; return result; };
    const roleOf = (auth) => String(auth.token.role || 'employee');
    const safeError = (_error) => '翻訳を作成できませんでした。';
    const toHttpsError = (error) => { if (error instanceof https_1.HttpsError)
        throw error; if (error instanceof zod_1.z.ZodError)
        throw new https_1.HttpsError('invalid-argument', error.issues[0]?.message || '入力を確認してください。'); throw new https_1.HttpsError('unavailable', 'お知らせの処理を完了できませんでした。'); };
    async function userProfile(uid) {
        const snapshot = await firestore.doc(`users/${uid}`).get();
        if (!snapshot.exists || snapshot.data()?.active === false)
            throw new https_1.HttpsError("permission-denied", "利用できないアカウントです。");
        return snapshot.data();
    }
    function demoFields(profile) {
        if (profile.isDemo !== true)
            return {};
        const demoDatasetId = String(profile.demoDatasetId || "");
        const seedVersion = String(profile.seedVersion || "");
        if (!demoDatasetId || !seedVersion)
            throw new https_1.HttpsError("failed-precondition", "デモアカウント設定が不完全です。");
        return { isDemo: true, demoDatasetId, seedVersion };
    }
    function instructionScopeFields(profile) {
        return profile.isDemo === true ? demoFields(profile) : { isDemo: false };
    }
    function sameDemoScope(profile, row) {
        return profile.isDemo === true
            ? row.isDemo === true && String(row.demoDatasetId || "") === String(profile.demoDatasetId || "")
            : row.isDemo !== true;
    }
    function requireSameDemoScope(profile, row) {
        if (!sameDemoScope(profile, row))
            throw new https_1.HttpsError("permission-denied", "デモデータの範囲が一致しません。");
    }
    const instructionDate = zod_1.z.string().refine((value) => {
        if (value === "")
            return true;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value))
            return false;
        const parsed = new Date(`${value}T00:00:00Z`);
        return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
    }, "期限の日付を確認してください。");
    const instructionAttachmentContentTypes = [
        "image/jpeg",
        "image/png",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ];
    const instructionAttachmentSchema = zod_1.z.object({
        id: zod_1.z.string().uuid(),
        name: zod_1.z.string().trim().min(1).max(180),
        contentType: zod_1.z.enum(instructionAttachmentContentTypes),
        size: zod_1.z.number().int().positive().max(10 * 1024 * 1024),
        storagePath: zod_1.z.string().min(1).max(500)
    });
    const instructionInputSchema = zod_1.z.object({
        instructionId: zod_1.z.string().uuid(),
        title: zod_1.z.string().trim().min(1, "件名を入力してください。").max(120),
        body: zod_1.z.string().trim().min(1, "お知らせ内容を入力してください。").max(8000),
        priority: zod_1.z.enum(["normal", "urgent"]),
        dueDate: instructionDate.optional().default(""),
        recipientIds: zod_1.z.array(zod_1.z.string().trim().min(1).max(128)).min(1, "対象者を選択してください。").max(50),
        attachments: zod_1.z.array(instructionAttachmentSchema).max(5).default([])
    }).superRefine((input, context) => {
        if (new Set(input.recipientIds).size !== input.recipientIds.length) {
            context.addIssue({ code: zod_1.z.ZodIssueCode.custom, message: "対象者が重複しています。", path: ["recipientIds"] });
        }
        if (new Set(input.attachments.map((item) => item.id)).size !== input.attachments.length) {
            context.addIssue({ code: zod_1.z.ZodIssueCode.custom, message: "添付資料が重複しています。", path: ["attachments"] });
        }
        if (input.attachments.reduce((sum, item) => sum + item.size, 0) > 20 * 1024 * 1024) {
            context.addIssue({ code: zod_1.z.ZodIssueCode.custom, message: "添付資料の合計は20MBまでです。", path: ["attachments"] });
        }
    });
    function instructionStoragePrefix(profile, instructionId, uid) {
        return profile.isDemo === true
            ? `demo/${String(profile.demoDatasetId)}/president-instructions/${instructionId}/${uid}/`
            : `president-instructions/${instructionId}/${uid}/`;
    }
    function safeInstructionFilename(name) {
        return name.normalize("NFKC").replace(/[^\p{L}\p{N}._-]+/gu, "_").slice(0, 80) || "attachment";
    }
    function instructionFileSignatureMatches(bytes, contentType) {
        if (contentType === "image/jpeg")
            return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
        if (contentType === "image/png")
            return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        if (contentType === "application/pdf")
            return bytes.length >= 5 && bytes.subarray(0, 5).toString("ascii") === "%PDF-";
        return bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && [0x03, 0x05, 0x07].includes(bytes[2]) && [0x04, 0x06, 0x08].includes(bytes[3]);
    }
    async function verifiedInstructionAttachment(object, input, expectedOwnerId, expectedInstructionId) {
        const [metadata] = await object.getMetadata();
        const contentType = String(metadata.contentType || "");
        const size = Number(metadata.size || 0);
        const custom = metadata.metadata || {};
        if (contentType !== input.contentType || size !== input.size)
            throw new https_1.HttpsError("invalid-argument", `${input.name} のファイル情報が一致しません。`);
        if (expectedOwnerId && String(custom.ownerId || "") !== expectedOwnerId)
            throw new https_1.HttpsError("permission-denied", "添付資料の所有者が一致しません。");
        if (expectedInstructionId && String(custom.instructionId || "") !== expectedInstructionId)
            throw new https_1.HttpsError("permission-denied", "添付資料のお知らせIDが一致しません。");
        const perFileLimit = contentType.startsWith("image/") ? 1024 * 1024 : 10 * 1024 * 1024;
        if (!Number.isFinite(size) || size <= 0 || size > perFileLimit)
            throw new https_1.HttpsError("invalid-argument", `${input.name} の容量を確認してください。`);
        const [bytes] = await object.download();
        if (bytes.length !== size || !instructionFileSignatureMatches(bytes, input.contentType))
            throw new https_1.HttpsError("invalid-argument", `${input.name} のファイル形式を確認してください。`);
        return { ...input, size, contentType: input.contentType };
    }
    async function prepareInstructionAttachments(auth, profile, input, replacesInstructionId) {
        if (!input.attachments.length)
            return [];
        const bucket = (0, storage_1.getStorage)().bucket();
        const newPrefix = instructionStoragePrefix(profile, input.instructionId, auth.uid);
        let replacedAttachments = [];
        if (replacesInstructionId) {
            const replaced = await firestore.doc(`presidentInstructions/${replacesInstructionId}`).get();
            if (!replaced.exists || replaced.data()?.status !== "active")
                throw new https_1.HttpsError("failed-precondition", "再発信できる有効なお知らせがありません。");
            requireSameDemoScope(profile, replaced.data());
            if (String(replaced.data()?.authorId || "") !== auth.uid)
                throw new https_1.HttpsError("permission-denied", "発信者本人だけが再発信できます。");
            replacedAttachments = zod_1.z.array(instructionAttachmentSchema).max(5).parse(replaced.data()?.attachments || []);
        }
        return Promise.all(input.attachments.map(async (attachment) => {
            const retained = replacedAttachments.find((item) => item.id === attachment.id
                && item.storagePath === attachment.storagePath
                && item.name === attachment.name
                && item.contentType === attachment.contentType
                && item.size === attachment.size);
            if (retained) {
                const source = bucket.file(retained.storagePath);
                const checked = await verifiedInstructionAttachment(source, retained);
                const destinationPath = `${newPrefix}${checked.id}-${safeInstructionFilename(checked.name)}`;
                const destination = bucket.file(destinationPath);
                await source.copy(destination);
                await destination.setMetadata({
                    contentType: checked.contentType,
                    metadata: {
                        ownerId: auth.uid,
                        instructionId: input.instructionId,
                        ...(profile.isDemo === true ? { isDemo: "true", demoDatasetId: String(profile.demoDatasetId) } : {})
                    }
                });
                return { ...checked, storagePath: destinationPath };
            }
            if (!attachment.storagePath.startsWith(newPrefix))
                throw new https_1.HttpsError("permission-denied", "添付資料の保存先がお知らせと一致しません。");
            const basename = attachment.storagePath.slice(newPrefix.length);
            if (!basename.startsWith(`${attachment.id}-`) || basename.includes("/"))
                throw new https_1.HttpsError("permission-denied", "添付資料のファイル名が正しくありません。");
            return verifiedInstructionAttachment(bucket.file(attachment.storagePath), attachment, auth.uid, input.instructionId);
        }));
    }
    async function instructionRecipients(authorProfile, recipientIds, authorId) {
        const snapshots = await firestore.getAll(...recipientIds.map((uid) => firestore.doc(`users/${uid}`)));
        return snapshots.map((snapshot) => {
            if (!snapshot.exists)
                throw new https_1.HttpsError("not-found", "対象者が見つかりません。");
            const data = snapshot.data();
            if (snapshot.id === authorId)
                throw new https_1.HttpsError("invalid-argument", "自分自身を宛先にはできません。");
            if (data.active === false)
                throw new https_1.HttpsError("invalid-argument", "有効な利用者を宛先にしてください。");
            requireSameDemoScope(authorProfile, data);
            return { userId: snapshot.id, displayName: String(data.displayName || "") };
        });
    }
    function instructionRecipientStates(recipients) {
        return Object.fromEntries(recipients.map((recipient) => [recipient.userId, {
                userId: recipient.userId,
                displayName: recipient.displayName,
                status: "pending"
            }]));
    }
    async function creationState(id) { const row = (await firestore.doc('presidentInstructions/' + id).get()).data(); return { id, translationStatus: row?.translationStatus || 'pending' }; }
    let translationLeaseId;
    async function translateInstructionAndUpdate(instructionId, uid) {
        stage = 'translate';
        const apiKey = dependencies.getApiKey();
        if (!apiKey)
            throw new Error("OpenAI APIキーが設定されていません。");
        const ref = firestore.doc(`presidentInstructions/${instructionId}`);
        const snapshot = await ref.get();
        if (!snapshot.exists)
            throw new https_1.HttpsError("not-found", "お知らせがありません。");
        const row = snapshot.data();
        const leaseId = (0, node_crypto_1.randomUUID)();
        const claimed = await firestore.runTransaction(async (tx) => { const current = (await tx.get(ref)).data(); if (!current)
            throw new https_1.HttpsError('not-found', 'お知らせがありません。'); if (current.translationLeaseUntil instanceof firestore_1.Timestamp && current.translationLeaseUntil.toMillis() > Date.now())
            return false; if (Number(current.translationAttempts || 0) >= 5)
            throw new https_1.HttpsError('resource-exhausted', '翻訳の再実行上限に達しました。'); tx.update(ref, { translationAttempts: firestore_1.FieldValue.increment(1), translationStatus: 'pending', translationError: firestore_1.FieldValue.delete(), translationLeaseId: leaseId, translationLeaseUntil: firestore_1.Timestamp.fromMillis(Date.now() + 150000), updatedAt: firestore_1.FieldValue.serverTimestamp() }); return true; });
        if (!claimed)
            return;
        translationLeaseId = leaseId;
        let translated;
        if (dependencies.translate) {
            translated = await dependencies.translate({ title: row.titleOriginal, body: row.bodyOriginal, sourceLocale: row.sourceLocale || 'ja', uid });
        }
        else {
            const client = new openai_1.default({ apiKey });
            const response = await client.responses.create({
                model: "gpt-5.6-luna",
                reasoning: { effort: "low" },
                safety_identifier: (0, node_crypto_1.createHash)("sha256").update(uid).digest("hex").slice(0, 32),
                input: [
                    { role: "system", content: row.sourceLocale === "zh-CN" ? "Translate the supplied Simplified Chinese company announcement into natural Japanese. Preserve names, dates, deadlines, urgency, uncertainty, and line breaks. Do not add facts. Return only a JSON object with keys title and body." : "Translate the supplied Japanese company announcement into natural, direct Simplified Chinese. Preserve names, dates, deadlines, urgency, uncertainty, and line breaks. Do not add facts. Return only a JSON object with keys title and body." },
                    { role: "user", content: JSON.stringify({ title: row.titleOriginal, body: row.bodyOriginal }) }
                ],
                text: { format: translatedInstructionFormat }
            });
            translated = zod_1.z.object({ title: zod_1.z.string().max(500), body: zod_1.z.string().max(12000) }).parse(JSON.parse(response.output_text));
        }
        await firestore.runTransaction(async (tx) => { const current = (await tx.get(ref)).data(); if (current?.translationLeaseId !== leaseId)
            return; tx.update(ref, { ...(row.sourceLocale === "zh-CN" ? { titleJa: translated.title, bodyJa: translated.body } : { titleZh: translated.title, bodyZh: translated.body }), translationStatus: "completed", translationLeaseId: firestore_1.FieldValue.delete(), translationLeaseUntil: firestore_1.FieldValue.delete(), translationError: firestore_1.FieldValue.delete(), updatedAt: firestore_1.FieldValue.serverTimestamp() }); });
    }
    async function markInstructionTranslationFailed(instructionId, auth, error) {
        const profile = await userProfile(auth.uid);
        const ref = firestore.doc(`presidentInstructions/${instructionId}`);
        const changed = await firestore.runTransaction(async (tx) => { const row = (await tx.get(ref)).data(); if (!row || row.translationStatus === 'completed' || (translationLeaseId ? row.translationLeaseId !== translationLeaseId : row.translationLeaseId))
            return false; tx.update(ref, { translationStatus: 'failed', translationError: safeError(error), translationLeaseId: firestore_1.FieldValue.delete(), translationLeaseUntil: firestore_1.FieldValue.delete(), updatedAt: firestore_1.FieldValue.serverTimestamp() }); return true; });
        if (!changed)
            return;
        await firestore.collection("auditEvents").add({
            actorId: auth.uid,
            subjectUserId: auth.uid,
            entityType: "president_instruction",
            entityId: instructionId,
            action: "translation_failed",
            reason: safeError(error),
            createdAt: firestore_1.FieldValue.serverTimestamp(),
            ...instructionScopeFields(profile)
        });
    }
    async function createInstruction(auth, input, replacesInstructionId = "", cancellationReason = "") {
        const requestFingerprint = (0, node_crypto_1.createHash)("sha256").update(JSON.stringify({ input, replacesInstructionId, cancellationReason })).digest("hex");
        const existing = await firestore.doc(`presidentInstructions/${input.instructionId}`).get();
        const checkExisting = (row) => { if (row.authorId !== auth.uid || row.submissionFingerprint !== requestFingerprint)
            throw new https_1.HttpsError("already-exists", "同じ送信IDを別の内容に使用できません。"); return { id: input.instructionId, created: false }; };
        if (existing.exists)
            return checkExisting(existing.data());
        const authorProfile = await userProfile(auth.uid);
        const recipients = await instructionRecipients(authorProfile, input.recipientIds, auth.uid);
        const attachments = await prepareInstructionAttachments(auth, authorProfile, input, replacesInstructionId);
        const replacedRef = replacesInstructionId ? firestore.doc(`presidentInstructions/${replacesInstructionId}`) : null;
        const ref = firestore.doc(`presidentInstructions/${input.instructionId}`);
        const now = firestore_1.FieldValue.serverTimestamp();
        const instructionData = {
            submissionFingerprint: requestFingerprint,
            authorId: auth.uid,
            authorName: String(authorProfile.displayName || "発信者"),
            authorRole: roleOf(auth),
            sourceLocale: authorProfile.locale === "zh-CN" ? "zh-CN" : "ja",
            titleOriginal: input.title,
            bodyOriginal: input.body,
            translationStatus: "pending",
            translationAttempts: 0,
            priority: input.priority,
            dueDate: input.dueDate,
            attachments,
            recipientIds: recipients.map((recipient) => recipient.userId),
            recipientStates: instructionRecipientStates(recipients),
            status: "active",
            ...(replacesInstructionId ? { replacesInstructionId } : {}),
            createdAt: now,
            updatedAt: now,
            ...instructionScopeFields(authorProfile)
        };
        const audit = firestore.collection("auditEvents").doc();
        const auditData = {
            actorId: auth.uid,
            subjectUserId: auth.uid,
            entityType: "president_instruction",
            entityId: ref.id,
            action: replacesInstructionId ? "reissued" : "created",
            after: { title: input.title, recipientIds: input.recipientIds, priority: input.priority, dueDate: input.dueDate, attachmentCount: attachments.length, attachmentNames: attachments.map((item) => item.name), replacesInstructionId },
            createdAt: now,
            ...instructionScopeFields(authorProfile)
        };
        return firestore.runTransaction(async (transaction) => {
            const current = await transaction.get(ref);
            if (current.exists)
                return checkExisting(current.data());
            const recipientSnapshots = await Promise.all(input.recipientIds.map(uid => transaction.get(firestore.doc('users/' + uid))));
            for (const snapshot of recipientSnapshots) {
                if (!snapshot.exists || snapshot.data()?.active === false)
                    throw new https_1.HttpsError('failed-precondition', '宛先の利用状態が変わりました。');
                requireSameDemoScope(authorProfile, snapshot.data());
            }
            if (replacedRef) {
                const replacedSnapshot = await transaction.get(replacedRef);
                if (!replacedSnapshot.exists || replacedSnapshot.data()?.status !== 'active')
                    throw new https_1.HttpsError('failed-precondition', '再発信できる有効なお知らせがありません。');
                requireSameDemoScope(authorProfile, replacedSnapshot.data());
                if (replacedSnapshot.data()?.authorId !== auth.uid)
                    throw new https_1.HttpsError('permission-denied', '発信者本人だけが再発信できます。');
                const cancelAudit = firestore.collection("auditEvents").doc();
                const cancelAuditData = {
                    actorId: auth.uid,
                    subjectUserId: auth.uid,
                    entityType: "president_instruction",
                    entityId: replacesInstructionId,
                    action: "cancelled_for_reissue",
                    reason: cancellationReason,
                    after: { replacedByInstructionId: ref.id },
                    createdAt: now,
                    ...instructionScopeFields(authorProfile)
                };
                transaction.update(replacedRef, { status: 'cancelled', cancelledAt: now, cancelledBy: auth.uid, cancellationReason, replacedByInstructionId: ref.id, updatedAt: now });
                transaction.create(cancelAudit, cancelAuditData);
            }
            transaction.create(ref, instructionData);
            transaction.create(audit, auditData);
            return { id: ref.id, created: true };
        });
    }
    const translatedInstructionFormat = { type: 'json_schema', name: 'translated_president_instruction', strict: true, schema: { type: 'object', properties: { title: { type: 'string' }, body: { type: 'string' } }, required: ['title', 'body'], additionalProperties: false } };
    const handlers = { createPresidentInstruction: async () => {
            try {
                const auth = await requireAuth(request.auth);
                const input = instructionInputSchema.parse(request.data);
                const { id, created } = await createInstruction(auth, input);
                if (!created)
                    return creationState(id);
                try {
                    await translateInstructionAndUpdate(id, auth.uid);
                    return creationState(id);
                }
                catch (error) {
                    await markInstructionTranslationFailed(id, auth, error);
                    return { id, translationStatus: "failed" };
                }
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        remindPresidentInstruction: async () => {
            try {
                const auth = await requireAuth(request.auth);
                return await (0, instructionReminders_js_1.sendInstructionReminder)(firestore, auth.uid, request.data);
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        replyToPresidentInstruction: async () => {
            try {
                const auth = await requireAuth(request.auth);
                return await (0, instructionMessages_js_1.sendInstructionMessage)(firestore, auth.uid, request.data);
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        acknowledgePresidentInstruction: async () => {
            try {
                const auth = await requireAuth(request.auth);
                const { instructionId } = zod_1.z.object({ instructionId: zod_1.z.string().min(1).max(128) }).parse(request.data);
                const profile = await userProfile(auth.uid);
                const ref = firestore.doc(`presidentInstructions/${instructionId}`);
                const changed = await firestore.runTransaction(async (transaction) => {
                    const snapshot = await transaction.get(ref);
                    if (!snapshot.exists)
                        throw new https_1.HttpsError("not-found", "お知らせがありません。");
                    const row = snapshot.data();
                    requireSameDemoScope(profile, row);
                    const state = row.recipientStates?.[auth.uid];
                    if (!state)
                        throw new https_1.HttpsError("permission-denied", "このお知らせの宛先ではありません。");
                    if (row.status === "cancelled")
                        throw new https_1.HttpsError("failed-precondition", "このお知らせは取り消されています。");
                    if (state.status !== "pending")
                        return false;
                    transaction.update(ref, {
                        recipientStates: { ...row.recipientStates, [auth.uid]: { ...state, status: "acknowledged", acknowledgedAt: firestore_1.Timestamp.now() } },
                        updatedAt: firestore_1.FieldValue.serverTimestamp()
                    });
                    return true;
                });
                if (changed)
                    await firestore.collection("auditEvents").add({ actorId: auth.uid, subjectUserId: auth.uid, entityType: "president_instruction", entityId: instructionId, action: "acknowledged", createdAt: firestore_1.FieldValue.serverTimestamp(), ...instructionScopeFields(profile) });
                return { ok: true };
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        completePresidentInstruction: async () => {
            try {
                const auth = await requireAuth(request.auth);
                const input = zod_1.z.object({ instructionId: zod_1.z.string().min(1).max(128), completionNote: zod_1.z.string().trim().max(2000).optional().default("") }).parse(request.data);
                const profile = await userProfile(auth.uid);
                const ref = firestore.doc(`presidentInstructions/${input.instructionId}`);
                const changed = await firestore.runTransaction(async (transaction) => {
                    const snapshot = await transaction.get(ref);
                    if (!snapshot.exists)
                        throw new https_1.HttpsError("not-found", "お知らせがありません。");
                    const row = snapshot.data();
                    requireSameDemoScope(profile, row);
                    const state = row.recipientStates?.[auth.uid];
                    if (!state)
                        throw new https_1.HttpsError("permission-denied", "このお知らせの宛先ではありません。");
                    if (row.status === "cancelled")
                        throw new https_1.HttpsError("failed-precondition", "このお知らせは取り消されています。");
                    if (state.status === "pending")
                        throw new https_1.HttpsError("failed-precondition", "先に内容を確認してください。");
                    if (state.status === "completed")
                        return false;
                    const recipientStates = { ...row.recipientStates, [auth.uid]: { ...state, status: "completed", completedAt: firestore_1.Timestamp.now(), completionNote: input.completionNote } };
                    const allCompleted = Object.values(recipientStates).every((recipient) => recipient.status === "completed");
                    transaction.update(ref, {
                        recipientStates,
                        status: allCompleted ? "completed" : "active",
                        ...(allCompleted ? { completedAt: firestore_1.FieldValue.serverTimestamp() } : {}),
                        updatedAt: firestore_1.FieldValue.serverTimestamp()
                    });
                    return true;
                });
                if (changed)
                    await firestore.collection("auditEvents").add({ actorId: auth.uid, subjectUserId: auth.uid, entityType: "president_instruction", entityId: input.instructionId, action: "completed", after: { completionNote: input.completionNote }, createdAt: firestore_1.FieldValue.serverTimestamp(), ...instructionScopeFields(profile) });
                return { ok: true };
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        cancelPresidentInstruction: async () => {
            try {
                const auth = await requireAuth(request.auth);
                const input = zod_1.z.object({ instructionId: zod_1.z.string().min(1).max(128), reason: zod_1.z.string().trim().min(3).max(500) }).parse(request.data);
                const profile = await userProfile(auth.uid);
                const ref = firestore.doc(`presidentInstructions/${input.instructionId}`);
                const changed = await firestore.runTransaction(async (transaction) => {
                    const snapshot = await transaction.get(ref);
                    if (!snapshot.exists)
                        throw new https_1.HttpsError("not-found", "お知らせがありません。");
                    const row = snapshot.data();
                    requireSameDemoScope(profile, row);
                    if (String(row.authorId || "") !== auth.uid)
                        throw new https_1.HttpsError("permission-denied", "発信者本人だけが取り消せます。");
                    if (row.status === "cancelled")
                        return false;
                    if (row.status === "completed")
                        throw new https_1.HttpsError("failed-precondition", "完了済みのお知らせは取り消せません。");
                    transaction.update(ref, { status: "cancelled", cancelledAt: firestore_1.FieldValue.serverTimestamp(), cancelledBy: auth.uid, cancellationReason: input.reason, updatedAt: firestore_1.FieldValue.serverTimestamp() });
                    return true;
                });
                if (changed)
                    await firestore.collection("auditEvents").add({ actorId: auth.uid, subjectUserId: auth.uid, entityType: "president_instruction", entityId: input.instructionId, action: "cancelled", reason: input.reason, createdAt: firestore_1.FieldValue.serverTimestamp(), ...instructionScopeFields(profile) });
                return { ok: true };
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        replacePresidentInstruction: async () => {
            try {
                const auth = await requireAuth(request.auth);
                const parsed = zod_1.z.object({ instructionId: zod_1.z.string().min(1).max(128), reason: zod_1.z.string().trim().min(3).max(500), replacement: instructionInputSchema }).parse(request.data);
                const { id, created } = await createInstruction(auth, parsed.replacement, parsed.instructionId, parsed.reason);
                if (!created)
                    return creationState(id);
                try {
                    await translateInstructionAndUpdate(id, auth.uid);
                    return creationState(id);
                }
                catch (error) {
                    await markInstructionTranslationFailed(id, auth, error);
                    return { id, translationStatus: "failed" };
                }
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        retryPresidentInstructionTranslation: async () => {
            try {
                const auth = await requireAuth(request.auth);
                const { instructionId } = zod_1.z.object({ instructionId: zod_1.z.string().min(1).max(128) }).parse(request.data);
                const profile = await userProfile(auth.uid);
                const snapshot = await firestore.doc(`presidentInstructions/${instructionId}`).get();
                if (!snapshot.exists)
                    throw new https_1.HttpsError("not-found", "お知らせがありません。");
                requireSameDemoScope(profile, snapshot.data());
                if (String(snapshot.data()?.authorId || "") !== auth.uid)
                    throw new https_1.HttpsError("permission-denied", "発信者本人だけが翻訳を再実行できます。");
                if (Number(snapshot.data()?.translationAttempts || 0) >= 5)
                    throw new https_1.HttpsError("resource-exhausted", "翻訳の再実行上限に達しました。");
                try {
                    await translateInstructionAndUpdate(instructionId, auth.uid);
                }
                catch (error) {
                    await markInstructionTranslationFailed(instructionId, auth, error);
                    throw error;
                }
                return { ok: true };
            }
            catch (error) {
                return toHttpsError(error);
            }
        },
        listAnnouncementRecipients: async () => {
            try {
                const auth = await requireAuth(request.auth);
                const profile = await userProfile(auth.uid);
                const snapshot = await firestore.collection("users").limit(100).get();
                const recipients = snapshot.docs
                    .filter((item) => item.data().active !== false && sameDemoScope(profile, item.data()))
                    .map((item) => ({
                    uid: item.id,
                    displayName: String(item.data().displayName || "").trim(),
                    role: String(item.data().role || "employee"),
                    active: true,
                    ...instructionScopeFields(item.data())
                }))
                    .filter((item) => item.displayName.length > 0)
                    .sort((a, b) => a.displayName.localeCompare(b.displayName, "ja"));
                return { recipients };
            }
            catch (error) {
                return toHttpsError(error);
            }
        } };
    try {
        const result = await handlers[operation]();
        dependencies.trace?.({ requestId, source: dependencies.source, operation, stage: 'completed', result: 'success' });
        return result;
    }
    catch (error) {
        dependencies.trace?.({ requestId, source: dependencies.source, operation, stage, result: 'failed', code: error instanceof https_1.HttpsError ? error.code : 'unavailable' });
        throw error;
    }
}
/** Recheck revocation/membership in every write transaction; audit origin is server-owned. */
function guardedFirestore(db, auth, authorize, source, requestId) {
    const enrich = (value) => value?.entityType === 'president_instruction' ? { ...value, source, requestId } : value;
    return new Proxy(db, { get(target, key) {
            if (key === 'runTransaction')
                return (work) => target.runTransaction(async (tx) => { await authorize(auth, tx); return work(new Proxy(tx, { get(t, k) { if (k === 'create')
                        return (ref, value) => t.create(ref, enrich(value)); const v = Reflect.get(t, k); return typeof v === 'function' ? v.bind(t) : v; } })); });
            if (key === 'collection')
                return (name) => { const collection = target.collection(name); if (name !== 'auditEvents')
                    return collection; return new Proxy(collection, { get(t, k) { if (k === 'add')
                        return (value) => t.add(enrich(value)); const v = Reflect.get(t, k); return typeof v === 'function' ? v.bind(t) : v; } }); };
            const value = Reflect.get(target, key);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
}
