"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireWorkAuth = requireWorkAuth;
const https_1 = require("firebase-functions/v2/https");
function failure(reason, message, code = "failed-precondition") {
    throw new https_1.HttpsError(code, message, { reason });
}
async function requireWorkAuth(auth, readProfile) {
    if (!auth)
        throw new https_1.HttpsError("unauthenticated", "ログインが必要です。");
    // Read current server state on every request; old ID tokens must not bypass the gate.
    const profile = await readProfile(auth.uid);
    if (!profile || profile.uid !== auth.uid || profile.active !== true
        || typeof profile.role !== "string" || !["employee", "employee_manager", "president_viewer"].includes(profile.role)) {
        failure("work-account-unavailable", "このアカウントでは勤怠を利用できません。管理担当者へ連絡してください。", "permission-denied");
    }
    if (profile.passwordChangeRequired === true) {
        failure("password-change-required", "先に新しいパスワードを設定してください。");
    }
    if ("passwordAuthTimeAfter" in profile) {
        const cutoff = profile.passwordAuthTimeAfter;
        const authTime = auth.token.auth_time;
        if (typeof cutoff !== "number" || !Number.isFinite(cutoff) || typeof authTime !== "number" || !Number.isFinite(authTime) || authTime <= cutoff) {
            failure("recent-login-required", "新しいパスワードでもう一度ログインしてください。");
        }
    }
    // Authorize with the latest server-owned role, without changing other claims
    // or the caller's original token. Existing password sign-ins remain valid.
    return { ...auth, token: { ...auth.token, role: profile.role } };
}
