import { Timestamp, type Firestore } from "firebase-admin/firestore";
import type { Message } from "firebase-admin/messaging";
import { type PasswordAuthContext } from "./workAuth.js";
export declare const PUSH_LIFETIME_MS: number;
type Sender = {
    send(message: Message): Promise<string>;
};
export declare function registerPushDevice(db: Firestore, auth: PasswordAuthContext | undefined, raw: unknown, now?: Timestamp, application?: 'gpt-kintai' | 'coco'): Promise<{
    registered: true;
}>;
export declare function unregisterPushDevice(db: Firestore, raw: unknown): Promise<{
    removed: true;
}>;
export declare function testPushDevice(db: Firestore, sender: Sender, auth: PasswordAuthContext | undefined, raw: unknown, now?: Timestamp): Promise<{
    accepted: true;
}>;
export declare function deliverAnnouncementPush(db: Firestore, sender: Sender, instructionId: string, now?: Timestamp): Promise<void>;
export {};
