import { type Firestore } from "firebase-admin/firestore";
export declare const INSTRUCTION_REMINDER_COOLDOWN_MS: number;
/** Persist a reminder event for the app's realtime listener, without sending external messages. */
export declare function sendInstructionReminder(firestore: Firestore, actorId: string | undefined, data: unknown): Promise<{
    ok: true;
    recipientCount: number;
}>;
