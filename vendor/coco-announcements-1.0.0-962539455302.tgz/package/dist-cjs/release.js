"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ANNOUNCEMENT_RELEASE = void 0;
exports.ANNOUNCEMENT_RELEASE = Object.freeze({ "version": "1.0.0", "sourceHash": "96253945530281c4b9e39e21fa4bbf2955fa790bac7831203cb876442e327cbf", "apiVersion": 1 });
