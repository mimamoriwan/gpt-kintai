"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ANNOUNCEMENT_RELEASE = void 0;
exports.ANNOUNCEMENT_RELEASE = Object.freeze({ "version": "1.0.1", "sourceHash": "d1ff78302b370dcf4189dfc9afdce31f2b70e2b94b92fdeba0791ab5bd9c910f", "apiVersion": 1 });
